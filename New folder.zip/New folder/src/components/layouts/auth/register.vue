<template>
  <div></div>
</template>
<script>
export default {
  name: "AppRegister",
  components: {},
  data() {
    return {};
  },
};
</script>
<style scoped></style>
