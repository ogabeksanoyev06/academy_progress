<template>
  <footer class="footer"></footer>
</template>

<script>
import "./footer.scss";

export default {
  name: "AppFooter",
};
</script>

<style scoped></style>
