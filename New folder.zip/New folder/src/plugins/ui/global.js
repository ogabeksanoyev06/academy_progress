import Vue from 'vue';

import AppText from '../../components/shared-components/AppText';

Vue.component('AppText', AppText);
