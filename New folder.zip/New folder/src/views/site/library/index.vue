<template>
  <div>
    <section class="py-40">
      <div></div>
    </section>
  </div>
</template>
<script>
export default {
  name: "AppLibrary",
  components: {},
  data() {
    return {};
  },
};
</script>
<style scoped></style>
